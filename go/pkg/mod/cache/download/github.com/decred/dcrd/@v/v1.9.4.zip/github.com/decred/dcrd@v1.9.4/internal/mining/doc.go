// Copyright (c) 2020 The Decred developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

/*
Package mining includes all mining and policy types, and will house all mining
code in the future.

It is currently a work in progress.
*/
package mining
