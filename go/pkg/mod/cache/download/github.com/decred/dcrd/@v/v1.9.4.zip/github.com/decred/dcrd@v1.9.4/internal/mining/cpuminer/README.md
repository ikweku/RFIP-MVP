
cpuminer
========

[![Build Status](https://github.com/decred/dcrd/workflows/Build%20and%20Test/badge.svg)](https://github.com/decred/dcrd/actions)
[![ISC License](https://img.shields.io/badge/license-ISC-blue.svg)](http://copyfree.org)
[![Doc](https://img.shields.io/badge/doc-reference-blue.svg)](https://pkg.go.dev/github.com/decred/dcrd/internal/mining/cpuminer)

Package cpuminer provides facilities for solving blocks (mining) using the CPU.

## Overview

This package is currently a work in progress.  It works without issue since it
is used in several of the integration tests, but the API is not really ready for
public consumption as it has simply been refactored out of the main codebase for
now.

## License

Package cpuminer is licensed under the [copyfree](http://copyfree.org) ISC
License.
