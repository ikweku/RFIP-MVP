# bavard

Internal package with some code-generation helper (txt/template and asm). 

Used by: 

* [gnark](https://github.com/consensys/gnark)
* [gurvy](https://github.com/consensys/gurvy)
* [goff](https://github.com/consensys/goff)